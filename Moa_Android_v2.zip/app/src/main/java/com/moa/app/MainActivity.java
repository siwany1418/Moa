package com.moa.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/moa.html");
    }

    private class Bridge {
        @JavascriptInterface
        public boolean accOn() {
            String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return s != null && s.contains(getPackageName() + "/");
        }

        @JavascriptInterface
        public void openAcc() {
            runOnUiThread(new Runnable() {
                public void run() {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                }
            });
        }

        @JavascriptInterface
        public void saveNative(String appsJson, String color, int strength) {
            try {
                JSONArray a = new JSONArray(appsJson);
                Set<String> set = new HashSet<>();
                for (int k = 0; k < a.length(); k++) set.add(a.getString(k));
                SharedPreferences.Editor e = getSharedPreferences("moa_native", Context.MODE_PRIVATE).edit();
                e.putStringSet("apps", set).putString("color", color).putInt("str", strength).apply();
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public String apps() {
            try {
                final PackageManager pm = getPackageManager();
                Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
                Set<String> seen = new HashSet<>();
                List<String[]> out = new ArrayList<>();
                for (ResolveInfo r : list) {
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                    out.add(new String[]{pkg, r.loadLabel(pm).toString()});
                }
                Collections.sort(out, new Comparator<String[]>() {
                    public int compare(String[] a, String[] b) {
                        return a[1].compareToIgnoreCase(b[1]);
                    }
                });
                JSONArray arr = new JSONArray();
                for (String[] a : out) {
                    arr.put(new JSONObject().put("p", a[0]).put("n", a[1]));
                }
                return arr.toString();
            } catch (Exception e) {
                return "[]";
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
