package com.moa.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import java.util.Collections;
import java.util.Set;

public class MoaService extends AccessibilityService {
    private WindowManager wm;
    private View overlay;

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        if (pkg.equals("com.android.systemui") || pkg.toLowerCase().contains("inputmethod") || pkg.toLowerCase().contains("keyboard")) return;
        SharedPreferences sp = getSharedPreferences("moa_native", Context.MODE_PRIVATE);
        Set<String> apps = sp.getStringSet("apps", Collections.<String>emptySet());
        int strength = sp.getInt("str", 35);
        if (apps.contains(pkg) && strength > 0) show(sp.getString("color", "#000000"), strength);
        else hide();
    }

    private void show(String hex, int strength) {
        hide();
        int c;
        try { c = Color.parseColor(hex); } catch (Exception ex) { c = Color.BLACK; }
        View v = new View(this);
        v.setBackgroundColor(Color.argb(strength * 255 / 100, Color.red(c), Color.green(c), Color.blue(c)));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try { wm.addView(v, lp); overlay = v; } catch (Exception ignored) { }
    }

    private void hide() {
        if (overlay != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
            overlay = null;
        }
    }

    @Override
    public void onInterrupt() { hide(); }

    @Override
    public void onDestroy() { hide(); super.onDestroy(); }
}
